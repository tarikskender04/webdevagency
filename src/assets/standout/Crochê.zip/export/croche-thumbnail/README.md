# Crochê — showcase card

Thumbnail for the Crochê project in the agency site's "Selected work" carousel.

## Files
- `index.html`: standalone reference with all CSS inline (the `.croche-card` block).
- `assets/croche-hero.png`: background photo.
- `assets/croche-logo-white.svg`: white primary logo (vector).

## Spec
- Aspect ratio 3:4 (designed at 900×1200). Everything scales with card width through `cqw` units, so the card can be any size.
- Photo: full-bleed `object-fit: cover`.
- Shade: vertical gradient in `#150C0C`. 55% at the top, clear at 30%, 15% at 50%, 72% at 75%, 90% at the bottom.
- Logo: 46.67% of card width, centred, bottom edge of the group at 10.67% of card width from the bottom.
- Tagline: "HAND-CROCHETED BAGS · SARAJEVO", JetBrains Mono 500, 2.67% of card width, letter-spacing .24em, white. Gap to the logo is 3.78% of card width.

## Implementing
Copy the `.croche-card` markup and CSS into the carousel card component. Move the assets into the site's public folder and update the `src` paths. Remove the `body` rule; it only centres the preview.
